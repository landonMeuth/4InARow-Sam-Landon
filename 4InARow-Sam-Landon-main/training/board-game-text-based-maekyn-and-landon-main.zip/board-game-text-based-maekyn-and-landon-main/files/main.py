#import
import os

from termcolor import colored

from drawBoard import Board

from colorama import init
init(autoreset = True)
#vars
currentPlayer="Red"

win=False

move=9

#- = blank
#x = red
#o = yellow

board=[["-","-","-","-","-","-","-"],
       ["-","-","-","-","-","-","-"],
       ["-","-","-","-","-","-","-"],
       ["-","-","-","-","-","-","-"],
       ["-","-","-","-","-","-","-"],
       ["-","-","-","-","-","-","-"],]

#defs

def checkForWins():
    global win
    for word in ["xxxx","oooo"]: #pulls word to search for
        for row in range(len(board)): #imagin a pointer combing through every row and column of the word search.
            for column in range(len(board[row])):
                for scanDirection in [[1,0,"down"],[-1,0,"up"],[0,1,"right"],[0,-1,"left"],[1,1,"right down"],[-1,-1,"left up"],[1,-1,"left down"],[-1,1,"right up"]]: #the scan direction is the direction that the word is going
                    checksum=0 #the checksum should equal the word length. if it does then the word was found.
                    for i in range(len(word)):
                        if (row+(i*scanDirection[0]))<0 or (row+(i*scanDirection[0]))>(len(board)-1) or (column+(i*scanDirection[1]))<0 or (column+(i*scanDirection[1]))>(len(board[row])-1): #makes sure the scanner doesn't go out of bounds
                            pass
                        elif word[i].lower()==board[row+(i*scanDirection[0])][column+(i*scanDirection[1])].lower():#each letter is thouroughly checked
                            checksum+=1
                    if checksum==len(word):
                        win=True #makes a list of where the words are
    
    return(win)

def makeAMove():
    checksum=0
    global currentPlayer
    gravity=5
    
    if currentPlayer=="red":
        currentPlayer="blue"
    else:
        currentPlayer="red"
        
    while True: #loop makes sure input is valid
        move = input(f"what move would you like to make player {colored(currentPlayer,currentPlayer)} ")
        if move in ["1","2","3","4","5","6","7"]:
            move=int(move)
            if board[0][move-1] in ["x","o"]: #disallows putting peice in full column
                print(colored("You cant make that move","red"))
            else:
                break
            
        else:
            print(colored("You cant make that move","red"))
    
    while board[gravity][move-1] in ["x","o"]: #simulates gravity of peice
        gravity-=1
    
    if currentPlayer=="red": #swaps who the player is so they can make turns
        board[gravity][move-1]="x"
    else:
        board[gravity][move-1]="o"
    
#main operation
while True:
    os.system('cls') #clears board
    print("Welcome to 4 In A Row!\n\nType numbers 1 through 7 to drop a peice in their respective columns.\nTry to get 4 pieces to connect together to win.\n")
    if checkForWins()==False: 
        print(Board(board))
        makeAMove()
    else:
        print(Board(board))
        input(f"{currentPlayer} Player Wins!")
        board=[["-","-","-","-","-","-","-"],
               ["-","-","-","-","-","-","-"],
               ["-","-","-","-","-","-","-"],
               ["-","-","-","-","-","-","-"],
               ["-","-","-","-","-","-","-"],
               ["-","-","-","-","-","-","-"],]
        win=False
        
        