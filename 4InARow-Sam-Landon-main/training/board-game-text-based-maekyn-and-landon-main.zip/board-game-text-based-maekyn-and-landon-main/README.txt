Thank you for installing "4 In A Row" for you Personal Computer!
To run this properly, you must have python installed onto your computer, and then run the install file called 'install.bat'.
For your own safty, inspect the content of this file.
Double click the file to install Python and all the appropriate extensions.
Once this is completed, you may run "4 In A Row" by double clicking the file 'run.bat'.
Enjoy!

Credits:
	Maekyn Grigsby
	Landon Meuth

License:
	This program belongs to the public to freely distribute, modify, and use.
	The program has no license, so you could make money off of it, you cheapskate!
